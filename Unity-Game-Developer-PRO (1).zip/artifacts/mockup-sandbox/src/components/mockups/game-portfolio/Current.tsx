import './_group.css';
import { useEffect, useState } from 'react';
import { portfolio, type Project } from '@/data/portfolio';
import {
  ArrowDownRight,
  ArrowUpRight,
  Code2,
  Menu,
  MoveRight,
  ShieldCheck,
  X,
} from 'lucide-react';
export default function Current() {
  const [menuOpen, setMenuOpen] = useState(false);
  const displayName = portfolio.name.trim();
  const siteTitle = displayName ? `${displayName} — Unity 3D & 2D Game Developer` : 'Unity 3D & 2D Game Developer';
  const projects = portfolio.projects.filter((project) => project.title.trim());

  useEffect(() => {
    document.title = siteTitle;
    const description =
      'Independent Unity and C# game development for 2D and 3D games. From complete production to focused gameplay systems.';
    let metaDescription = document.querySelector<HTMLMetaElement>('meta[name="description"]');
    if (!metaDescription) {
      metaDescription = document.createElement('meta');
      metaDescription.name = 'description';
      document.head.appendChild(metaDescription);
    }
    metaDescription.content = description;
    const setSocialMeta = (property: string, content: string) => {
      let tag = document.querySelector<HTMLMetaElement>(`meta[property="${property}"]`);
      if (!tag) {
        tag = document.createElement('meta');
        tag.setAttribute('property', property);
        document.head.appendChild(tag);
      }
      tag.content = content;
    };
    setSocialMeta('og:title', siteTitle);
    setSocialMeta('og:description', description);
    setSocialMeta('og:type', 'website');
    const setTwitterMeta = (name: string, content: string) => {
      let tag = document.querySelector<HTMLMetaElement>(`meta[name="${name}"]`);
      if (!tag) {
        tag = document.createElement('meta');
        tag.name = name;
        document.head.appendChild(tag);
      }
      tag.content = content;
    };
    setTwitterMeta('twitter:card', 'summary');
    setTwitterMeta('twitter:title', siteTitle);
    setTwitterMeta('twitter:description', description);
  }, [siteTitle]);

  const closeMenu = () => setMenuOpen(false);
  const projectPlayUrl = (project: Project) => {
    const raw = project.googlePlayUrl?.trim();
    if (!raw) return undefined;
    try {
      const url = new URL(raw);
      if (
        url.protocol === 'https:' &&
        url.hostname === 'play.google.com' &&
        url.pathname === '/store/apps/details' &&
        url.searchParams.has('id')
      ) {
        return url.href;
      }
    } catch {
      return undefined;
    }
    return undefined;
  };
  const contacts = [
    safeExternalUrl(portfolio.socials.linkedin) && { label: 'LinkedIn', href: safeExternalUrl(portfolio.socials.linkedin)! },
    safeExternalUrl(portfolio.socials.github) && { label: 'GitHub', href: safeExternalUrl(portfolio.socials.github)! },
    safeExternalUrl(portfolio.socials.instagram) && { label: 'Instagram', href: safeExternalUrl(portfolio.socials.instagram)! },
  ].filter((contact): contact is { label: string; href: string } => Boolean(contact));
  const upworkUrl = safeUpworkUrl(portfolio.upwork);
  const email = portfolio.email.trim();
  const contactLinks: { label: string; href: string; external: boolean; primary: boolean }[] = [
    email && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
      ? { label: 'Email', href: `mailto:${email}`, external: false, primary: false }
      : null,
    upworkUrl ? { label: 'Hire me on Upwork', href: upworkUrl, external: true, primary: true } : null,
    email && !upworkUrl && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
      ? { label: 'Hire me', href: `mailto:${email}`, external: false, primary: true }
      : null,
    ...contacts.map((contact) => ({ ...contact, external: true, primary: false })),
  ].filter((link): link is { label: string; href: string; external: boolean; primary: boolean } => Boolean(link));

  return (
    <main className="portfolio-page">
      <header className="site-header">
        <a className="brand-mark" href="#top" onClick={closeMenu} aria-label="Back to top">
          <span className="brand-symbol">U</span>
          <span>{portfolio.name.trim() || 'GAME DEVELOPER'}<span className="brand-caption">UNITY / C#</span></span>
        </a>
        <button className="menu-toggle" onClick={() => setMenuOpen((open) => !open)} aria-label={menuOpen ? 'Close navigation' : 'Open navigation'} aria-expanded={menuOpen} data-testid="button-toggle-menu">
          {menuOpen ? <X size={19} /> : <Menu size={19} />}
        </button>
        <nav className={`nav-links${menuOpen ? ' open' : ''}`} aria-label="Main navigation">
          <a href="#about" onClick={closeMenu}>About</a>
          <a href="#work" onClick={closeMenu}>Selected work</a>
          <a href="#capabilities" onClick={closeMenu}>Capabilities</a>
          <a href="#approach" onClick={closeMenu}>Why work together</a>
          <a className="nav-contact" href="#contact" onClick={closeMenu}>Let’s talk <ArrowUpRight size={13} /></a>
        </nav>
      </header>

      <section className="hero" id="top">
        <div className="hero-copy">
          <p className="eyebrow">Independent game development</p>
          <h1>Unity <span>3D &amp; 2D</span><br />Game Developer</h1>
          <p className="hero-lede">
            I create engaging 2D and 3D games, gameplay systems, UI, scenes, and complete game experiences using Unity and C#.
          </p>
          <div className="hero-actions">
            <a className="button-primary" href="#work">Explore the work <ArrowDownRight size={16} /></a>
            <a className="text-link" href="#contact">Have a game in mind? <MoveRight size={14} /></a>
          </div>
          <div className="hero-footnote"><ShieldCheck size={14} /> 2D & 3D · End-to-end or component work</div>
        </div>
        <div className="hero-art" role="img" aria-label="Original atmospheric illustration of a distant game-world horizon at dusk">
          <div className="art-coordinate" />
          <div className="scene-frame">
            <div className="scene-sky" />
            <div className="scene-sun" />
            <div className="scene-moon" />
            <div className="mountain-back" />
            <div className="mountain" />
            <div className="scene-ground" />
            <div className="scene-path" />
            <div className="scene-grid" />
            <div className="scene-index">Playable worlds / 001</div>
            <div className="scene-caption">Build the feeling. Then the system.</div>
          </div>
          <div className="art-note">UNITY<br />C#<br />PLAYABLE BY DESIGN</div>
        </div>
      </section>

      <div className="ticker" aria-label="Specialties">
        <div className="ticker-inner">
          <span><i /> Unity & C#</span><span><i /> 2D / 3D</span><span><i /> Gameplay systems</span><span><i /> Mobile-ready</span><span><i /> Full production</span>
        </div>
      </div>

      <section className="section about-section" id="about">
        <div className="about-copy">
          <span className="section-kicker">01 / About me</span>
          <h2 className="section-title">I build with<br />the player in mind.</h2>
        </div>
        <div className="about-details">
          <p>I’m a Unity and C# game developer drawn to the craft behind a satisfying play experience: responsive controls, clear feedback, and systems that support the fun. I work across 2D and 3D, building complete games from concept through playable delivery—or focused pieces like UI, scenes, gameplay systems, and features for an existing project.</p>
        </div>
      </section>

      <section className="section work-section" id="work">
        <div className="section-heading">
          <div>
            <span className="section-kicker">02 / Selected work</span>
            <h2 className="section-title">Built to be played.</h2>
          </div>
          <p className="section-aside">A look at the worlds, mechanics, and details I’ve helped bring together.</p>
        </div>
        {projects.length ? (
          <div className="project-grid">
            {projects.map((project, index) => {
              const playUrl = projectPlayUrl(project);
              return (
                <article className="project-card" key={`${project.title}-${index}`} data-testid={`card-project-${index}`}>
                  <div className="project-image">
                    {project.image ? <img src={project.image} alt={`${project.title} game artwork`} /> : <div className="project-image-art" />}
                    <span className="project-image-label">{project.genre || 'Game project'} / {String(index + 1).padStart(2, '0')}</span>
                  </div>
                  <div className="project-info">
                    <div className="project-meta">
                      {project.genre && <span>{project.genre}</span>}
                      {project.platform && <span>{project.platform}</span>}
                    </div>
                    <h3 className="project-title">{project.title}</h3>
                    <p className="project-desc">{project.description}</p>
                    {project.features?.length ? <ul className="project-features">{project.features.map((feature) => <li key={feature}>{feature}</li>)}</ul> : null}
                    {project.screenshots?.length ? <div className="gallery-strip" aria-label={`${project.title} screenshots`}>{project.screenshots.map((screenshot, shotIndex) => <img key={screenshot} src={screenshot} alt={`${project.title} screenshot ${shotIndex + 1}`} />)}</div> : null}
                    {playUrl && <div className="project-actions"><a href={playUrl} target="_blank" rel="noopener noreferrer">Play on Google Play <ArrowUpRight size={14} /></a></div>}
                  </div>
                </article>
              );
            })}
          </div>
        ) : (
          <div className="empty-work">
            <div className="empty-art" aria-hidden="true"><div className="empty-orbit" /></div>
            <div className="empty-content">
              <p className="eyebrow">A new world starts here</p>
              <h3>Your first published game belongs here.</h3>
              <p>This space is ready for a real project: its artwork, the mechanics behind it, and the details that make the experience yours. No placeholder games—just room for your work to take center stage.</p>
              <span className="empty-file-note"><Code2 size={14} /> Add your game in <code>src/data/portfolio.ts</code></span>
            </div>
          </div>
        )}
      </section>

      <section className="services-section" id="capabilities">
        <div className="services-inner">
          <div className="section-heading">
            <div>
          <span className="section-kicker">03 / What I build</span>
              <h2 className="section-title">From first input<br />to final frame.</h2>
            </div>
            <p className="section-aside">The full experience—or a focused piece of the puzzle. Scope shaped around your game, not a preset package.</p>
          </div>
          <div className="services-grid">
            <article className="service"><span className="service-number">01 — BUILD</span><h3>Complete Unity game development</h3><p>Build a complete 2D or 3D game—from the core loop and scenes through polish, mobile optimization, and a finished playable experience.</p></article>
            <article className="service"><span className="service-number">02 — FEEL</span><h3>Gameplay & player systems</h3><p>Player controllers, mechanics, interaction, animation, AI, and the rules that make play feel responsive.</p></article>
            <article className="service"><span className="service-number">03 — WORLD</span><h3>Scenes, levels & missions</h3><p>Environments, level flow, mission logic, UI, and menus—built to guide players without getting in their way.</p></article>
            <article className="service"><span className="service-number">04 — MOVE</span><h3>Vehicles & racing systems</h3><p>Driving controls, race progression, vehicle behavior, and supporting systems tuned around the game’s feel.</p></article>
            <article className="service"><span className="service-number">05 — SHIP</span><h3>Android & mobile</h3><p>Touch-friendly play, mobile UI, practical device-aware implementation, and performance-conscious delivery.</p></article>
            <article className="service"><span className="service-number">06 — REFINE</span><h3>Optimization & bug fixes</h3><p>Find the friction, make the fix, and improve stability and performance without disturbing what already works.</p></article>
            <article className="service"><span className="service-number">07 — CONNECT</span><h3>Animation & interaction</h3><p>Bring objects, characters, and interfaces to life with deliberate feedback and cleanly connected behavior.</p></article>
            <article className="service"><span className="service-number">08 — DESIGN</span><h3>Tailored gameplay systems</h3><p>A specific mechanic or technical challenge? Build the right-sized solution around your design constraints.</p></article>
          </div>
          <p className="skills-kicker">Tools &amp; skills</p>
          <div className="stackline">
            <span>Unity</span><span>C#</span><span>2D game development</span><span>3D game development</span>
            <span>Game UI</span><span>Gameplay programming</span><span>Game mechanics</span><span>Level design</span>
            <span>AI systems</span><span>Game scenes</span><span>Animation &amp; interaction</span><span>Android game development</span>
          </div>
        </div>
      </section>

      <section className="section approach-section" id="approach">
        <div className="approach-intro">
          <span className="section-kicker">04 / The working relationship</span>
          <h2 className="section-title">Good games need<br />good collaboration.</h2>
          <p>Clear scope, considered decisions, and a steady line of communication. The way we build matters as much as what we build.</p>
        </div>
        <div className="reason-list">
          <article className="reason"><span className="reason-num">01</span><div><h3>Clean, functional systems</h3><p>Gameplay code should be legible, dependable, and made to serve the experience—not add complexity for its own sake.</p></div></article>
          <article className="reason"><span className="reason-num">02</span><div><h3>Focused communication</h3><p>Direct updates, clear questions, and shared expectations keep decisions moving and the work pointed at the goal.</p></div></article>
          <article className="reason"><span className="reason-num">03</span><div><h3>Whole game or one key piece</h3><p>Work together end to end, or bring in a specialist for a controller, system, level, mobile pass, or stubborn bug.</p></div></article>
          <article className="reason"><span className="reason-num">04</span><div><h3>Solutions shaped to your game</h3><p>Every project has its own constraints. Implementation follows the design, audience, and team—not a copy-paste recipe.</p></div></article>
        </div>
      </section>

      <section className="contact-section" id="contact">
        <div className="contact-inner">
          <div>
            <span className="section-kicker">05 / Start a conversation</span>
            <h2 className="contact-title">Have a game<br />in mind?</h2>
            <p className="contact-copy">Share what you’re making, where you’re stuck, or the system you want to bring to life. We can start with the problem and work out the right scope.</p>
          </div>
          {contactLinks.length ? (
            <div className="contact-links">
              {contactLinks.map((link) => (
                <a
                  className={`contact-link${link.primary ? ' is-primary' : ''}`}
                  href={link.href}
                  key={`${link.label}-${link.href}`}
                  {...(link.external ? { target: '_blank', rel: 'noopener noreferrer' } : {})}
                >
                  {link.label} {link.external && <ArrowUpRight size={13} />}
                </a>
              ))}
            </div>
          ) : (
            <p className="contact-config-note">Add your email or Upwork link to <code>src/data/portfolio.ts</code> to make contact buttons appear here.</p>
          )}
        </div>
      </section>
      <footer className="footer">
        <span>{portfolio.name.trim() || 'INDEPENDENT UNITY GAME DEVELOPER'} · UNITY / C#</span>
        <span>Thoughtful systems. Playable worlds.</span>
        {contacts.length > 0 && <nav className="footer-links" aria-label="Social links">{contacts.map((contact) => <a key={contact.label} href={contact.href} target="_blank" rel="noopener noreferrer">{contact.label} <ArrowUpRight size={10} /></a>)}</nav>}
      </footer>
    </main>
  );
}

function safeExternalUrl(value: string): string | undefined {
  if (!value.trim()) return undefined;
  try {
    const url = new URL(value);
    return url.protocol === 'https:' ? url.href : undefined;
  } catch {
    return undefined;
  }
}

function safeUpworkUrl(value: string): string | undefined {
  const safeUrl = safeExternalUrl(value);
  if (!safeUrl) return undefined;
  const hostname = new URL(safeUrl).hostname;
  return hostname === 'upwork.com' || hostname.endsWith('.upwork.com') ? safeUrl : undefined;
}
