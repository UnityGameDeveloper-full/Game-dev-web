import './_group.css';
import { useEffect, useRef, useState } from 'react';
import { portfolio, type Project } from '@/data/portfolio-updated';
import {
  ArrowDownRight,
  ArrowUpRight,
  Check,
  ChevronRight,
  CircleDot,
  Cpu,
  Gamepad2,
  Layers3,
  Mail,
  Menu,
  MoveRight,
  Smartphone,
  ShieldCheck,
  Sparkles,
  Waypoints,
  X,
} from 'lucide-react';

export default function Updated() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const lastFocus = useRef<HTMLElement | null>(null);
  const siteTitle = 'Muhammad Awais | Unity 2D & 3D Game Developer';
  const description = 'Muhammad Awais is a Unity 2D and 3D Game Developer specializing in C#, gameplay programming, game UI, game mechanics, AI systems, mobile games and complete game development.';
  const projects = portfolio.projects.filter((project) => project.title.trim());

  useEffect(() => {
    document.title = siteTitle;
    let metaDescription = document.querySelector<HTMLMetaElement>('meta[name="description"]');
    if (!metaDescription) {
      metaDescription = document.createElement('meta');
      metaDescription.name = 'description';
      document.head.appendChild(metaDescription);
    }
    metaDescription.content = description;
    const setSocialMeta = (property: string, content: string) => {
      let tag = document.querySelector<HTMLMetaElement>(`meta[property="${property}"]`);
      if (!tag) {
        tag = document.createElement('meta');
        tag.setAttribute('property', property);
        document.head.appendChild(tag);
      }
      tag.content = content;
    };
    setSocialMeta('og:title', siteTitle);
    setSocialMeta('og:description', description);
    setSocialMeta('og:type', 'website');
    const setTwitterMeta = (name: string, content: string) => {
      let tag = document.querySelector<HTMLMetaElement>(`meta[name="${name}"]`);
      if (!tag) {
        tag = document.createElement('meta');
        tag.name = name;
        document.head.appendChild(tag);
      }
      tag.content = content;
    };
    setTwitterMeta('twitter:card', 'summary');
    setTwitterMeta('twitter:title', siteTitle);
    setTwitterMeta('twitter:description', description);
  }, [siteTitle]);

  useEffect(() => {
    if (!selectedProject) return;
    const previousFocus = lastFocus.current;
    document.querySelector<HTMLButtonElement>('.dialog-close')?.focus();
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setSelectedProject(null);
      if (event.key === 'Tab') {
        const items = document.querySelectorAll<HTMLElement>('.project-dialog a[href], .project-dialog button:not([disabled])');
        const first = items[0];
        const last = items[items.length - 1];
        if (event.shiftKey && document.activeElement === first) {
          event.preventDefault();
          last?.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault();
          first?.focus();
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      previousFocus?.focus();
    };
  }, [selectedProject]);

  const closeMenu = () => setMenuOpen(false);
  const projectPlayUrl = (project: Project): string | undefined => {
    const raw = project.playStoreLink?.trim();
    if (!raw || raw === 'PLAY_STORE_LINK_HERE') return undefined;
    try {
      const url = new URL(raw);
      return url.protocol === 'https:' && url.hostname === 'play.google.com' &&
        url.pathname === '/store/apps/details' && Boolean(url.searchParams.get('id')) ? url.href : undefined;
    } catch {
      return undefined;
    }
  };
  const skills = [
    'Unity', 'C#', '2D Game Development', '3D Game Development', 'Gameplay Programming',
    'Game Mechanics', 'Game UI', 'Game Scenes', 'Level Design', 'Level Systems',
    'AI Systems', 'Player Controllers', 'Enemy Systems', 'Animation & Interaction',
    'Android Game Development', 'Game Optimization', 'Bug Fixing',
  ];
  const services = [
    { icon: Gamepad2, number: '01', title: 'Complete Game Development', text: 'Complete 2D and 3D games developed in Unity.' },
    { icon: Cpu, number: '02', title: 'Unity Game Development', text: 'Professional gameplay development using Unity and C#.' },
    { icon: Waypoints, number: '03', title: 'Gameplay Programming', text: 'Gameplay mechanics, player controls, interactions and systems.' },
    { icon: Layers3, number: '04', title: 'Game UI Development', text: 'Menus, HUDs, buttons, panels, settings and complete game interfaces.' },
    { icon: Sparkles, number: '05', title: 'Game Scenes & Environments', text: 'Game scenes, environments, level layouts and scene functionality.' },
    { icon: CircleDot, number: '06', title: 'Level Design & Level Systems', text: 'Levels, checkpoints, missions, progression and level management systems.' },
    { icon: Cpu, number: '07', title: 'AI Development', text: 'Enemy AI, NPC behavior, waypoint systems and intelligent game interactions.' },
    { icon: Waypoints, number: '08', title: 'Game Mechanics', text: 'Custom mechanics and gameplay features based on project requirements.' },
    { icon: Smartphone, number: '09', title: 'Mobile Game Development', text: 'Android-focused Unity game development.' },
    { icon: ShieldCheck, number: '10', title: 'Bug Fixing & Optimization', text: 'Fix existing Unity problems, improve functionality and optimize projects.' },
  ];
  const reasons = [
    'Unity & C# focused development', '2D and 3D game development', 'Complete game development',
    'Individual feature development', 'Custom gameplay systems', 'Professional game UI',
    'Mobile game development', 'AI and gameplay systems', 'Clean and functional implementation',
    'Client-focused development',
  ];
  const process = [
    { number: '01', title: 'Discuss', text: 'Understand the client’s idea and requirements.' },
    { number: '02', title: 'Plan', text: 'Plan gameplay, features, UI and development structure.' },
    { number: '03', title: 'Develop', text: 'Build the game or required features in Unity using C#.' },
    { number: '04', title: 'Deliver', text: 'Test, optimize and deliver a functional final product.' },
  ];

  return (
    <main className="portfolio-page">
      <a href="#top" className="skip-link">Skip to content</a>
      <header className="site-header">
        <a className="brand-mark" href="#top" onClick={closeMenu} aria-label="Back to top">
          <span className="brand-symbol">A</span>
          <span className="brand-name">{portfolio.name}<span className="brand-caption">UNITY / C#</span></span>
        </a>
        <button className="menu-toggle" onClick={() => setMenuOpen((open) => !open)} aria-label={menuOpen ? 'Close navigation' : 'Open navigation'} aria-expanded={menuOpen} aria-controls="primary-navigation" data-testid="button-toggle-menu">
          {menuOpen ? <X size={19} /> : <Menu size={19} />}
        </button>
        <nav className={`nav-links${menuOpen ? ' open' : ''}`} id="primary-navigation" aria-label="Main navigation">
          <a href="#top" onClick={closeMenu}>Home</a>
          <a href="#about" onClick={closeMenu}>About</a>
          <a href="#skills" onClick={closeMenu}>Skills</a>
          <a href="#work" onClick={closeMenu}>Games</a>
          <a href="#capabilities" onClick={closeMenu}>Services</a>
          <a className="nav-contact" href="#contact" onClick={closeMenu}>Contact <ArrowUpRight size={13} /></a>
        </nav>
      </header>

      <section className="hero" id="top">
        <div className="hero-copy">
          <p className="eyebrow">Independent game development · Unity / C#</p>
          <h1><span className="hero-name">Muhammad Awais</span><span className="hero-role">Unity 2D &amp; 3D</span><br />Game Developer</h1>
          <p className="hero-lede">
            Building immersive 2D and 3D games, gameplay systems, UI, scenes, mechanics and complete gaming experiences with Unity and C#.
          </p>
          <div className="hero-actions">
            <a className="button-primary" href="#work">View My Games <ArrowDownRight size={16} /></a>
            <a className="text-link" href="#contact">Hire Me <MoveRight size={14} /></a>
          </div>
          <div className="hero-footnote"><ShieldCheck size={14} /> Concept to playable delivery <span aria-hidden="true">·</span> Complete game or one feature</div>
        </div>
        <div className="hero-art" role="img" aria-label="Original atmospheric illustration of a distant game-world horizon at dusk">
          <div className="art-coordinate" />
          <div className="scene-frame">
            <div className="scene-sky" />
            <div className="scene-sun" />
            <div className="scene-moon" />
            <div className="mountain-back" />
            <div className="mountain" />
            <div className="scene-ground" />
            <div className="scene-path" />
            <div className="scene-grid" />
            <div className="scene-index">Playable worlds / 001</div>
            <div className="scene-caption">Build the feeling. Then the system.</div>
          </div>
          <div className="art-note">UNITY<br />C#<br />PLAYABLE BY DESIGN</div>
        </div>
      </section>

      <div className="ticker" aria-label="Specialties">
        <div className="ticker-inner">
          <span><i /> Unity &amp; C#</span><span><i /> 2D / 3D games</span><span><i /> Gameplay systems</span><span><i /> Android games</span><span><i /> Full production</span>
        </div>
      </div>

      <section className="section about-section" id="about">
        <div className="about-copy">
          <span className="section-kicker">01 / About</span>
          <h2 className="section-title">About Me</h2>
          <div className="about-visual" role="img" aria-label="Abstract game development landscape with layered terrain and a central orbital form">
            <span className="visual-orbit" />
            <span className="visual-label">Ideas become playable worlds / Unity · C#</span>
          </div>
        </div>
        <div className="about-details">
          <p>I am a passionate Unity Game Developer focused on creating engaging and functional 2D and 3D games. I work with Unity and C# to build gameplay systems, game mechanics, UI, environments, levels, AI systems, animations and complete game experiences.<br /><br />Whether you need a complete game developed from scratch or only a specific feature added to an existing project, I can help turn your idea into a functional and polished Unity project.</p>
          <aside className="about-note">FROM FIRST IDEA<br />TO A FUNCTIONAL, PLAYABLE BUILD.</aside>
        </div>
      </section>

      <section className="section work-section" id="work">
        <div className="section-heading">
          <div>
            <span className="section-kicker">02 / Project worlds</span>
            <h2 className="section-title">My Games</h2>
          </div>
          <p className="section-aside">Explore some of my Unity game development projects. Each image is concept artwork representing the world—not a gameplay screenshot.</p>
        </div>
        {projects.length ? (
          <div className="project-grid">
            {projects.map((project, index) => {
              const playUrl = projectPlayUrl(project);
              return (
                <article className="project-card" key={`${project.title}-${index}`} data-testid={`card-project-${index}`}>
                  <div className="project-image">
                    <img src={project.image} alt={`Concept artwork for ${project.title}: ${project.genre} world`} loading="lazy" width="1024" height="1024" />
                    <span className="project-image-label">{project.genre || 'Game project'} / {String(index + 1).padStart(2, '0')}</span>
                    <span className="artwork-note">Concept artwork</span>
                  </div>
                  <div className="project-info">
                    <div className="project-meta">
                      {project.genre && <span>{project.genre}</span>}
                      {project.platform && <span>{project.platform}</span>}
                    </div>
                    <h3 className="project-title">{project.title}</h3>
                    <p className="project-desc">{project.description}</p>
                    {project.features?.length ? <ul className="project-features">{project.features.map((feature) => <li key={feature}>{feature}</li>)}</ul> : null}
                    <div className="project-actions">
                      <button className="details-button" type="button" onClick={(event) => { lastFocus.current = event.currentTarget; setSelectedProject(project); }} aria-haspopup="dialog" data-testid={`button-view-details-${index}`}>View Details <ChevronRight size={14} /></button>
                      {playUrl
                        ? <a className="play-link" href={playUrl} target="_blank" rel="noopener noreferrer" data-testid={`link-google-play-${index}`}>Play on Google Play <ArrowUpRight size={14} /></a>
                        : <button className="play-unavailable" type="button" disabled title="Google Play link not yet available" data-testid={`button-google-play-unavailable-${index}`}>Google Play unavailable</button>}
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        ) : <p className="empty-work">Game projects will appear here.</p>}
      </section>

      <section className="services-section" id="capabilities">
        <div className="services-inner">
          <div className="section-heading">
            <div>
              <span className="section-kicker">03 / Services</span>
              <h2 className="section-title">Game Development Services</h2>
            </div>
            <p className="section-aside">I can develop a complete game from concept to playable product, or work on a specific feature of your existing Unity project.</p>
          </div>
          <div className="services-grid">
            {services.map(({ icon: Icon, number, title, text }) => (
              <article className="service" key={number}>
                <span className="service-number">{number} / SERVICE</span>
                <span className="service-icon"><Icon size={19} strokeWidth={1.5} aria-hidden="true" /></span>
                <h3>{title}</h3><p>{text}</p>
              </article>
            ))}
          </div>
          <div className="skills-wrap" id="skills">
            <p className="skills-kicker">04 / Skills &amp; toolkit</p>
            <div className="stackline">{skills.map((skill) => <span key={skill}>{skill}</span>)}</div>
          </div>
        </div>
      </section>

      <section className="feature-section" aria-labelledby="feature-heading">
        <div className="feature-inner">
          <div>
            <span className="section-kicker">A flexible way to build</span>
            <h2 className="feature-title" id="feature-heading">Need a Complete Game or Just One Feature?</h2>
            <div className="feature-copy">
              <p>Whether you need a complete game built from scratch or only one specific part of your existing project, I can help.</p>
              <p>You can hire me to develop a complete game, or request individual work such as UI, gameplay mechanics, game scenes, level systems, AI, player controllers, animations, or custom functionality.</p>
            </div>
            <a className="button-primary" href="#contact">Let’s Work Together <MoveRight size={15} /></a>
          </div>
          <aside className="feature-aside">
            <span>One collaboration, your scope</span>
            <p>Start with the whole idea, or bring one clear requirement from a project already in motion. The work can fit the game you’re making.</p>
          </aside>
        </div>
      </section>

      <section className="section approach-section" id="approach">
        <div className="approach-intro">
          <span className="section-kicker">05 / Why work together</span>
          <h2 className="section-title">Why Work<br />With Me?</h2>
          <p>Focused Unity development, thoughtful implementation, and work shaped around the game and the client.</p>
        </div>
        <div className="reason-list" aria-label="Reasons to work with Muhammad Awais">
          {reasons.map((reason) => <article className="reason" key={reason}><span className="reason-num"><Check size={15} /></span><div><h3>{reason}</h3></div></article>)}
        </div>
      </section>

      <section className="section process-section" id="process">
        <div className="process-inner">
          <span className="section-kicker">06 / From brief to build</span>
          <h2 className="section-title">My Development Process</h2>
          <div className="process-grid">
            {process.map((step) => <article className="process-step" key={step.number}><span>{step.number} — {step.title.toUpperCase()}</span><h3>{step.title}</h3><p>{step.text}</p></article>)}
          </div>
        </div>
      </section>

      <section className="contact-section" id="contact">
        <div className="contact-inner">
          <div>
            <span className="section-kicker">07 / Contact</span>
            <h2 className="contact-title">Let’s Build<br />Your Game</h2>
            <p className="contact-copy">Have a game idea or need help with an existing Unity project? Let’s discuss your requirements.</p>
            <p className="contact-detail">EMAIL · {portfolio.email}<br />WHATSAPP · +92 303 8999792</p>
          </div>
          <div className="contact-links">
            <a className="contact-link is-primary" href={`mailto:${portfolio.email}`} data-testid="link-send-email">Send Me an Email <Mail size={14} /></a>
            <a className="contact-link" href={portfolio.whatsapp} target="_blank" rel="noopener noreferrer" data-testid="link-whatsapp">Chat on WhatsApp <ArrowUpRight size={13} /></a>
            <a className="contact-link" href={`mailto:${portfolio.email}?subject=${encodeURIComponent('Game development project')}`} data-testid="link-hire-me">Hire Me <ArrowUpRight size={13} /></a>
          </div>
        </div>
      </section>
      <footer className="footer">
        <div className="footer-identity"><strong>{portfolio.name}</strong><span>{portfolio.role}</span><span>Creating games, systems and experiences with Unity &amp; C#.</span></div>
        <nav className="footer-nav" aria-label="Footer navigation">
          <a href="#top">Home</a><a href="#about">About</a><a href="#skills">Skills</a><a href="#work">Games</a><a href="#capabilities">Services</a><a href="#contact">Contact</a>
          <a href={`mailto:${portfolio.email}`}>Email</a><a href={portfolio.whatsapp} target="_blank" rel="noopener noreferrer">WhatsApp</a>
        </nav>
        <span className="copyright">© 2026 Muhammad Awais. All Rights Reserved.</span>
      </footer>
      {selectedProject && (
        <div className="project-dialog-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setSelectedProject(null); }}>
          <section className="project-dialog" role="dialog" aria-modal="true" aria-labelledby="project-dialog-title" aria-describedby="project-dialog-description">
            <button className="dialog-close" type="button" aria-label="Close project details" onClick={() => setSelectedProject(null)}><X size={19} /></button>
            <img className="dialog-image" src={selectedProject.image} alt={`Concept artwork for ${selectedProject.title}`} width="1024" height="1024" />
            <div className="dialog-copy">
              <span className="dialog-meta">{selectedProject.genre} · {selectedProject.platform}</span>
              <h2 id="project-dialog-title">{selectedProject.title}</h2>
              <p id="project-dialog-description">{selectedProject.description}</p>
              {selectedProject.features?.length ? <ul className="project-features">{selectedProject.features.map((feature) => <li key={feature}>{feature}</li>)}</ul> : null}
              <p className="dialog-note">Artwork shown is illustrative concept art, not a gameplay screenshot.</p>
              {projectPlayUrl(selectedProject)
                ? <a className="play-link" href={projectPlayUrl(selectedProject)} target="_blank" rel="noopener noreferrer" data-testid="link-google-play-dialog">Play on Google Play <ArrowUpRight size={14} /></a>
                : <button className="play-unavailable" type="button" disabled title="Google Play link not yet available" data-testid="button-google-play-unavailable-dialog">Google Play unavailable</button>}
            </div>
          </section>
        </div>
      )}
    </main>
  );
}

