/**
 * Owner-editable portfolio content.
 * Add your profile and contact details here. Keep empty contact fields empty until ready.
 *
 * To add a game: copy the commented example object into `projects`, replace the fields,
 * and use paths to image files stored inside `public/` (for example `/games/cover.jpg`).
 * Screenshot paths work the same way. Google Play links are only shown when the URL
 * is a valid https://play.google.com/store/apps/details?id=... address.
 */
export type Project = {
  title: string;
  description: string;
  image?: string;
  screenshots?: string[];
  features?: string[];
  genre?: string;
  platform?: string;
  googlePlayUrl?: string;
};

export const portfolio = {
  name: '',
  role: 'Independent Unity Game Developer',
  location: '',
  email: '',
  upwork: '',
  socials: {
    linkedin: '',
    github: '',
    instagram: '',
  },
  projects: [
    // Example:
    // {
    //   title: 'Your game title',
    //   description: 'A short, specific description of what makes the game work.',
    //   image: '/games/your-game-cover.jpg',
    //   screenshots: ['/games/your-game-screen-01.jpg', '/games/your-game-screen-02.jpg'],
    //   features: ['Vehicle handling', 'Race progression', 'Mobile UI'],
    //   genre: 'Racing',
    //   platform: 'Android',
    //   googlePlayUrl: 'https://play.google.com/store/apps/details?id=com.example.game',
    // },
  ] as Project[],
};