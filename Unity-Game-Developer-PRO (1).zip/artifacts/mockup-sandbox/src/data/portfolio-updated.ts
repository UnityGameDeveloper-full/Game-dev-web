/**
 * Owner-editable portfolio content.
 * Add your profile and contact details here. Keep empty contact fields empty until ready.
 *
 * To add a game: copy the commented example object into `projects`, replace the fields,
 * and use paths to image files stored inside `public/` (for example `/games/cover.jpg`).
 * Screenshot paths work the same way. Google Play links are only shown when the URL
 * is a valid https://play.google.com/store/apps/details?id=... address.
 */
export type Project = {
  title: string;
  description: string;
  image: string;
  features?: string[];
  genre?: string;
  platform?: string;
  playStoreLink: string;
};

export const portfolio = {
  name: 'Muhammad Awais',
  role: 'Unity 2D & 3D Game Developer',
  email: 'aewais123@gmail.com',
  whatsapp: 'https://wa.me/923038999792',
  projects: [
    { title: 'Lion Simulator', image: '/__mockup/images/lion-simulator.jpg', description: 'Experience the wild as a powerful lion. Explore the environment, survive, and experience an immersive animal simulation.', genre: 'Animal Simulator', platform: 'Android', features: ['Environment exploration', 'Animal simulation'], playStoreLink: 'PLAY_STORE_LINK_HERE' },
    { title: 'Shark Simulator', image: '/__mockup/images/shark-simulator.jpg', description: 'Explore the underwater world as a powerful shark and experience an exciting ocean survival adventure.', genre: 'Animal / Simulation', platform: 'Android', features: ['Underwater exploration', 'Ocean survival'], playStoreLink: 'PLAY_STORE_LINK_HERE' },
    { title: 'Zombie Simulator', image: '/__mockup/images/zombie-simulator.jpg', description: 'Survive a dangerous world filled with zombies and experience intense survival gameplay.', genre: 'Zombie / Survival', platform: 'Android', features: ['Survival gameplay'], playStoreLink: 'PLAY_STORE_LINK_HERE' },
    { title: 'Wolf Simulator', image: '/__mockup/images/wolf-simulator.jpg', description: 'Explore the wilderness as a wolf and experience an immersive animal simulation adventure.', genre: 'Animal Simulator', platform: 'Android', features: ['Wilderness exploration', 'Animal simulation'], playStoreLink: 'PLAY_STORE_LINK_HERE' },
    { title: 'Werewolf Simulator', image: '/__mockup/images/werewolf-simulator.jpg', description: 'Enter a dark world and experience the power of a werewolf in an immersive supernatural simulation.', genre: 'Action / Simulation', platform: 'Android', features: ['Supernatural simulation'], playStoreLink: 'PLAY_STORE_LINK_HERE' },
    { title: 'Car Racing Game', image: '/__mockup/images/racing-simulator.jpg', description: 'Experience fast-paced racing with exciting tracks, vehicles, challenges and competitive gameplay.', genre: 'Racing', platform: 'Android', features: ['Tracks & vehicles', 'Racing challenges'], playStoreLink: 'PLAY_STORE_LINK_HERE' },
  ] as Project[],
};