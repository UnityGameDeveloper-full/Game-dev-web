import { Router, type IRouter } from "express";
import gameIdeasRouter from "./game-ideas";
import healthRouter from "./health";

const router: IRouter = Router();

router.use(healthRouter);
router.use(gameIdeasRouter);

export default router;
