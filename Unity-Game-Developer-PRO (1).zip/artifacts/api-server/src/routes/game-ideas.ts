import { ReplitConnectors } from "@replit/connectors-sdk";
import {
  SubmitGameIdeaBody,
  SubmitGameIdeaResponse,
} from "@workspace/api-zod";
import { Router, type IRouter } from "express";

const router: IRouter = Router();
const successMessage =
  "Thank you! Your game idea has been submitted. I'll review your idea and get back to you soon.";
const recipient = "aewais123@gmail.com";
const rateLimitWindowMs = 15 * 60 * 1000;
const maxSubmissionsPerWindow = 5;

type RateLimitEntry = {
  count: number;
  resetAt: number;
};

const submissionAttempts = new Map<string, RateLimitEntry>();
let lastRateLimitCleanup = 0;

function allowSubmission(ip: string, now: number): boolean {
  if (now - lastRateLimitCleanup >= 60_000) {
    for (const [key, entry] of submissionAttempts) {
      if (entry.resetAt <= now) submissionAttempts.delete(key);
    }
    lastRateLimitCleanup = now;
  }

  const current = submissionAttempts.get(ip);
  if (!current || current.resetAt <= now) {
    submissionAttempts.set(ip, {
      count: 1,
      resetAt: now + rateLimitWindowMs,
    });
    return true;
  }

  if (current.count >= maxSubmissionsPerWindow) return false;
  current.count += 1;
  return true;
}

router.post("/game-ideas", async (req, res): Promise<void> => {
  const parsed = SubmitGameIdeaBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({
      error: "Please check the form fields and try again.",
    });
    return;
  }

  const submission = parsed.data;

  // Silently accept likely bots without forwarding their content.
  if (submission.companyWebsite?.trim()) {
    res.json(SubmitGameIdeaResponse.parse({ message: successMessage }));
    return;
  }

  const clientIp = req.ip ?? req.socket.remoteAddress ?? "unknown";
  if (!allowSubmission(clientIp, Date.now())) {
    res.status(429).json({
      error: "Too many submissions. Please wait before trying again.",
    });
    return;
  }

  const from = process.env.RESEND_FROM_EMAIL?.trim();
  if (!from) {
    res.status(503).json({
      error:
        "Email delivery is not configured yet. Please use the WhatsApp link below.",
    });
    return;
  }

  const message = [
    "A new game idea was submitted through the portfolio.",
    "",
    `Name: ${submission.name}`,
    `Email: ${submission.email}`,
    `Game type: ${submission.gameType}`,
    `Dimension: ${submission.dimension}`,
    `Platform: ${submission.platform}`,
    "",
    "Game idea:",
    submission.gameIdea,
    "",
    "Additional requirements:",
    submission.additionalRequirements || "None provided",
  ].join("\n");

  try {
    const connectors = new ReplitConnectors();
    const providerResponse = await connectors.proxy("resend", "/emails", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        from,
        to: [recipient],
        reply_to: submission.email,
        subject: "New game idea submission",
        text: message,
      }),
    });

    if (!providerResponse.ok) {
      req.log.error(
        { statusCode: providerResponse.status },
        "Resend rejected a game idea submission",
      );
      res.status(502).json({
        error:
          "We couldn't send your idea just now. Please try again or use WhatsApp.",
      });
      return;
    }

    res.json(SubmitGameIdeaResponse.parse({ message: successMessage }));
  } catch (error) {
    req.log.error(
      {
        errorName: error instanceof Error ? error.name : "UnknownError",
      },
      "Game idea email delivery failed",
    );
    res.status(502).json({
      error:
        "We couldn't send your idea just now. Please try again or use WhatsApp.",
    });
  }
});

export default router;
