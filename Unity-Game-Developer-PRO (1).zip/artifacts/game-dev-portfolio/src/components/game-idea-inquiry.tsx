import { useState } from 'react';
import { zodResolver } from '@hookform/resolvers/zod';
import { useSubmitGameIdea } from '@workspace/api-client-react';
import { ArrowUpRight, Check, LoaderCircle, Send } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { portfolio } from '@/data/portfolio';
import { Button } from '@/components/ui/button';
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';

const formSchema = z.object({
  name: z.string().trim().min(2, 'Please enter at least 2 characters.').max(100, 'Please keep your name under 100 characters.'),
  email: z.string().trim().email('Enter a valid email address.').max(254, 'Email address is too long.'),
  gameIdea: z.string().trim().min(20, 'Tell me a little more about your game idea (at least 20 characters).').max(5000, 'Please keep your game idea under 5,000 characters.'),
  gameType: z.enum(['Action', 'Adventure', 'Racing', 'Shooting', 'Horror', 'Survival', 'Simulator', 'Puzzle', 'RPG', 'Casual', 'Other']),
  dimension: z.enum(['2D', '3D', 'Not Sure']),
  platform: z.enum(['Android', 'iOS', 'PC', 'Web', 'Other']),
  additionalRequirements: z.string().max(3000, 'Please keep additional requirements under 3,000 characters.'),
  companyWebsite: z.string().max(250).optional(),
});

type GameIdeaFormValues = z.infer<typeof formSchema>;

const defaultValues: GameIdeaFormValues = {
  name: '',
  email: '',
  gameIdea: '',
  gameType: 'Action',
  dimension: 'Not Sure',
  platform: 'Android',
  additionalRequirements: '',
  companyWebsite: '',
};

export function GameIdeaInquiry() {
  const mutation = useSubmitGameIdea();
  const [submitError, setSubmitError] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const form = useForm<GameIdeaFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues,
    mode: 'onBlur',
  });

  const onSubmit = (formValues: GameIdeaFormValues) => {
    setSubmitError('');
    setSubmitted(false);
    mutation.mutate(
      {
        data: {
          ...formValues,
          additionalRequirements: formValues.additionalRequirements || '',
          companyWebsite: '',
        },
      },
      {
        onSuccess: () => {
          setSubmitted(true);
          form.reset(defaultValues);
        },
        onError: () => {
          setSubmitError('Your idea could not be delivered right now. Please try again, or use WhatsApp to reach me directly.');
        },
      },
    );
  };

  return (
    <section className="game-inquiry-section" id="game-idea" aria-labelledby="game-inquiry-title">
      <div className="game-inquiry-inner">
        <div className="game-inquiry-heading">
          <span className="section-kicker">07 / Start a project</span>
          <h2 className="section-title" id="game-inquiry-title">Have a Game Idea? Let&apos;s Build It Together.</h2>
          <p>Have an idea for a game? Tell me about it. Whether you have a complete game concept or just a simple idea, share it with me and let&apos;s turn your idea into a playable game.</p>
          <div className="inquiry-assurance">
            <span className="assurance-mark"><Check size={15} aria-hidden="true" /></span>
            <span>A clear brief is a good place to begin. No commitment required.</span>
          </div>
        </div>

        <div className="game-inquiry-panel">
          <div className="inquiry-panel-top">
            <span>PROJECT BRIEF</span>
            <span className="inquiry-step">01 <i /> 01</span>
          </div>
          <Form {...form}>
            <form className="game-inquiry-form" onSubmit={form.handleSubmit(onSubmit)} noValidate data-testid="form-game-idea">
              <div className="inquiry-fields-grid">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem className="inquiry-field">
                      <FormLabel>Your Name <span aria-hidden="true">*</span></FormLabel>
                      <FormControl><Input {...field} autoComplete="name" placeholder="How should I address you?" data-testid="input-game-idea-name" /></FormControl>
                      <FormMessage data-testid="error-game-idea-name" />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem className="inquiry-field">
                      <FormLabel>Email Address <span aria-hidden="true">*</span></FormLabel>
                      <FormControl><Input {...field} type="email" autoComplete="email" placeholder="you@example.com" data-testid="input-game-idea-email" /></FormControl>
                      <FormMessage data-testid="error-game-idea-email" />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="gameType"
                  render={({ field }) => (
                    <FormItem className="inquiry-field">
                      <FormLabel>What type of game do you want? <span aria-hidden="true">*</span></FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-game-idea-type" aria-label="What type of game do you want?">
                            <SelectValue placeholder="Choose a game type" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {['Action', 'Adventure', 'Racing', 'Shooting', 'Horror', 'Survival', 'Simulator', 'Puzzle', 'RPG', 'Casual', 'Other'].map((option) => (
                            <SelectItem key={option} value={option}>{option}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage data-testid="error-game-idea-type" />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="dimension"
                  render={({ field }) => (
                    <FormItem className="inquiry-field">
                      <FormLabel>2D or 3D <span aria-hidden="true">*</span></FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-game-idea-dimension" aria-label="2D or 3D">
                            <SelectValue placeholder="Choose a dimension" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {['2D', '3D', 'Not Sure'].map((option) => <SelectItem key={option} value={option}>{option}</SelectItem>)}
                        </SelectContent>
                      </Select>
                      <FormMessage data-testid="error-game-idea-dimension" />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="platform"
                  render={({ field }) => (
                    <FormItem className="inquiry-field inquiry-field-platform">
                      <FormLabel>Platform <span aria-hidden="true">*</span></FormLabel>
                      <Select onValueChange={field.onChange} value={field.value}>
                        <FormControl>
                          <SelectTrigger data-testid="select-game-idea-platform" aria-label="Platform">
                            <SelectValue placeholder="Choose a platform" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {['Android', 'iOS', 'PC', 'Web', 'Other'].map((option) => <SelectItem key={option} value={option}>{option}</SelectItem>)}
                        </SelectContent>
                      </Select>
                      <FormMessage data-testid="error-game-idea-platform" />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="gameIdea"
                render={({ field }) => (
                  <FormItem className="inquiry-field inquiry-field-wide inquiry-field-concept">
                    <FormLabel>Game Idea / Concept <span aria-hidden="true">*</span></FormLabel>
                    <FormControl>
                      <Textarea {...field} rows={7} maxLength={5000} placeholder="What is the core idea? Describe the player, the world, or the moment that makes your game special." data-testid="textarea-game-idea-concept" />
                    </FormControl>
                    <FormDescription>Share as much or as little as you know so far. 20–5,000 characters.</FormDescription>
                    <FormMessage data-testid="error-game-idea-concept" />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="additionalRequirements"
                render={({ field }) => (
                  <FormItem className="inquiry-field inquiry-field-wide inquiry-field-requirements">
                    <FormLabel>Additional Requirements</FormLabel>
                    <FormControl>
                      <Textarea {...field} rows={4} maxLength={3000} placeholder="Features, references, timeline, or anything else I should know (optional)." data-testid="textarea-game-idea-requirements" />
                    </FormControl>
                    <FormDescription>Optional · Up to 3,000 characters</FormDescription>
                    <FormMessage data-testid="error-game-idea-requirements" />
                  </FormItem>
                )}
              />

              <input
                type="text"
                tabIndex={-1}
                autoComplete="off"
                aria-hidden="true"
                className="inquiry-honeypot"
                {...form.register('companyWebsite')}
                data-testid="input-game-idea-company-website"
              />

              {submitError && (
                <p className="inquiry-status inquiry-status-error" role="alert" data-testid="status-game-idea-error">{submitError}</p>
              )}
              {submitted && (
                <p className="inquiry-status inquiry-status-success" role="status" aria-live="polite" data-testid="status-game-idea-success">
                  <Check size={17} aria-hidden="true" />
                  <span>Thank you! Your game idea has been submitted. I&apos;ll review your idea and get back to you soon.</span>
                </p>
              )}

              <div className="inquiry-form-footer">
                <p className="inquiry-privacy">Your details are only used to reply to your project inquiry.</p>
                <Button type="submit" className="inquiry-submit" disabled={mutation.isPending} data-testid="button-submit-game-idea">
                  {mutation.isPending ? <><LoaderCircle className="inquiry-spinner" size={16} aria-hidden="true" /> Sending idea…</> : <>Submit My Game Idea <Send size={15} aria-hidden="true" /></>}
                </Button>
              </div>
              <div className="inquiry-whatsapp">
                <span>Prefer a direct conversation?</span>
                <a href={portfolio.whatsapp} target="_blank" rel="noopener noreferrer" data-testid="link-game-idea-whatsapp">
                  Discuss on WhatsApp <ArrowUpRight size={14} aria-hidden="true" />
                </a>
              </div>
            </form>
          </Form>
        </div>
      </div>
    </section>
  );
}
