import { useEffect, useRef, useState, type ReactNode } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import { GameIdeaInquiry } from '@/components/game-idea-inquiry';
import { portfolio, type Project } from '@/data/portfolio';
import { motion, useMotionValue, useSpring } from 'framer-motion';
import {
  ArrowDown, ArrowUpRight, Check, ChevronRight, CircleDot, Code2, Cpu,
  Gamepad2, Layers3, Mail, Menu, MoveRight, Smartphone, Sparkles,
  Target, Users, Waypoints, X, Zap
} from 'lucide-react';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';

const queryClient = new QueryClient();

const reveal = {
  hidden: { opacity: 0, y: 34 },
  show: { opacity: 1, y: 0, transition: { duration: 0.7, ease: [0.16, 1, 0.3, 1] } }
};

function Home() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [loaded, setLoaded] = useState(false);
  const lastFocus = useRef<HTMLElement | null>(null);
  const projects = portfolio.projects.filter((p) => p.title.trim());
  const siteTitle = 'Unity Game Developer | Unity 2D & 3D';
  const description = 'Unity Game Developer specializing in C#, gameplay systems, UI, AI, level design, mobile games and complete game development.';
  const mouseX = useMotionValue(0);
  const mouseY = useMotionValue(0);
  const smoothX = useSpring(mouseX, { stiffness: 70, damping: 20 });
  const smoothY = useSpring(mouseY, { stiffness: 70, damping: 20 });

  useEffect(() => {
    const timer = window.setTimeout(() => setLoaded(true), 450);
    document.title = siteTitle;
    let meta = document.querySelector<HTMLMetaElement>('meta[name="description"]');
    if (!meta) {
      meta = document.createElement('meta');
      meta.name = 'description';
      document.head.appendChild(meta);
    }
    meta.content = description;
    const onMove = (e: MouseEvent) => {
      mouseX.set((e.clientX / window.innerWidth - 0.5) * 2);
      mouseY.set((e.clientY / window.innerHeight - 0.5) * 2);
    };
    window.addEventListener('mousemove', onMove);
    return () => { clearTimeout(timer); window.removeEventListener('mousemove', onMove); };
  }, [mouseX, mouseY]);

  useEffect(() => {
    if (!selectedProject) return;
    const previousFocus = lastFocus.current;
    document.body.classList.add('modal-open');
    document.querySelector<HTMLButtonElement>('.dialog-close')?.focus();
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setSelectedProject(null);
    };
    window.addEventListener('keydown', onKey);
    return () => {
      document.body.classList.remove('modal-open');
      window.removeEventListener('keydown', onKey);
      previousFocus?.focus();
    };
  }, [selectedProject]);

  const closeMenu = () => setMenuOpen(false);
  const projectPlayUrl = (project: Project) => {
    const raw = project.playStoreLink?.trim();
    if (!raw || raw === 'PLAY_STORE_LINK_HERE') return undefined;
    try {
      const url = new URL(raw);
      return url.protocol === 'https:' && url.hostname === 'play.google.com' && url.pathname === '/store/apps/details' && url.searchParams.get('id') ? url.href : undefined;
    } catch { return undefined; }
  };

  const skills = ['Unity', 'C#', '3D Game Development', '2D Game Development', 'Gameplay Programming', 'Game Mechanics', 'Game UI', 'Level Design', 'Level Systems', 'AI Systems', 'Player Controllers', 'Enemy Systems', 'Animation & Interaction', 'Android Development', 'Optimization', 'Bug Fixing'];
  const services = [
    { icon: Gamepad2, title: 'Complete Game Development', text: 'From the first concept to a polished, playable Unity build.' },
    { icon: Code2, title: 'Gameplay Programming', text: 'Responsive controls, mechanics, interactions, missions and progression.' },
    { icon: Layers3, title: 'Game UI & UX', text: 'HUDs, menus, settings, panels and interfaces built for players.' },
    { icon: Waypoints, title: 'Level & World Systems', text: 'Scenes, checkpoints, level flow, environments and progression systems.' },
    { icon: Cpu, title: 'AI & Enemy Systems', text: 'NPC behavior, waypoint navigation, enemy logic and game-world reactions.' },
    { icon: Smartphone, title: 'Mobile Game Development', text: 'Android-focused Unity development with performance in mind.' },
  ];
  const process = [
    ['01', 'Discover', 'Understand the idea, target platform and gameplay goals.'],
    ['02', 'Design', 'Break the idea into systems, levels, UI and a clear development plan.'],
    ['03', 'Build', 'Implement gameplay and functionality in Unity with clean C# systems.'],
    ['04', 'Polish', 'Test, optimize, refine the experience and prepare the final build.'],
  ];
  const reasons = ['Unity + C# focused', 'Complete games or single features', '2D and 3D development', 'Gameplay-first implementation', 'Custom systems and mechanics', 'Mobile-ready workflows'];

  return (
    <main className="pro-site">
      {!loaded && <div className="site-loader"><div className="loader-mark">UNITY<span>DEV</span></div><div className="loader-line"><i /></div></div>}
      <motion.div className="cursor-glow" style={{ x: smoothX, y: smoothY }} />

      <header className="pro-header">
        <a className="pro-logo" href="#top" onClick={closeMenu}>
          <span className="logo-box">U</span>
          <span><strong>UNITY</strong><small>GAME DEVELOPER</small></span>
        </a>
        <button className="mobile-menu" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle navigation">{menuOpen ? <X /> : <Menu />}</button>
        <nav className={menuOpen ? 'pro-nav open' : 'pro-nav'}>
          {['About','Games','Services','Process'].map((item) => <a key={item} href={`#${item.toLowerCase()}`} onClick={closeMenu}>{item}</a>)}
          <a className="nav-cta" href="#contact" onClick={closeMenu}>Start a Project <ArrowUpRight size={14}/></a>
        </nav>
      </header>

      <section className="pro-hero" id="top">
        <div className="hero-grid" />
        <div className="hero-orb orb-one" />
        <div className="hero-orb orb-two" />
        <div className="hero-content">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: .25, duration: .7 }} className="hero-status">
            <span className="status-dot" /> AVAILABLE FOR GAME PROJECTS
          </motion.div>
          <motion.p initial="hidden" animate="show" variants={reveal} className="hero-mini">UNITY 3D · C# · GAMEPLAY SYSTEMS</motion.p>
          <motion.h1 initial="hidden" animate="show" variants={reveal}>
            BUILDING <span>WORLDS.</span><br />CREATING <em>EXPERIENCES.</em>
          </motion.h1>
          <motion.p initial="hidden" animate="show" variants={reveal} className="hero-description">
            Unity Game Developer creating immersive 2D & 3D games, gameplay systems, UI, AI and complete playable experiences with Unity and C#.
          </motion.p>
          <motion.div initial="hidden" animate="show" variants={reveal} className="hero-buttons">
            <a className="pro-btn primary" href="#games">Explore My Games <ArrowDown size={16}/></a>
            <a className="pro-btn ghost" href="#contact">Let's Build Together <MoveRight size={16}/></a>
          </motion.div>
          <div className="hero-stats">
            <div><b>UNITY</b><span>ENGINE</span></div>
            <div><b>C#</b><span>PROGRAMMING</span></div>
            <div><b>2D / 3D</b><span>DEVELOPMENT</span></div>
          </div>
        </div>

        <motion.div className="hero-profile" initial={{ opacity: 0, scale: .92, x: 35 }} animate={{ opacity: 1, scale: 1, x: 0 }} transition={{ delay: .45, duration: .9 }}>
          <div className="profile-ring ring-a" /><div className="profile-ring ring-b" />
          <div className="profile-card">
            <div className="profile-image">
              <img src="/game-art/racing-simulator.jpg" alt="Cinematic game developer visual" />
              <div className="profile-overlay" />
              <div className="profile-scan" />
              <span className="profile-code">DEV // 001</span>
            </div>
            <div className="profile-caption"><span>GAME DEVELOPER</span><strong>UNITY / C#</strong></div>
          </div>
          <div className="floating-chip chip-a"><Gamepad2 size={14}/> GAMEPLAY</div>
          <div className="floating-chip chip-b"><Zap size={14}/> SYSTEMS</div>
        </motion.div>
        <div className="scroll-cue"><span>SCROLL TO EXPLORE</span><ArrowDown size={14}/></div>
      </section>

      <section className="marquee"><div><span>UNITY</span><i>✦</i><span>C#</span><i>✦</i><span>GAMEPLAY</span><i>✦</i><span>AI SYSTEMS</span><i>✦</i><span>GAME UI</span><i>✦</i><span>LEVEL DESIGN</span><i>✦</i></div></section>

      <motion.section className="pro-section about" id="about" initial="hidden" whileInView="show" viewport={{ once:true, amount:.15 }} variants={reveal}>
        <div className="section-label">01 <span>ABOUT THE DEVELOPER</span></div>
        <div className="about-layout">
          <div><h2>Turning ideas into<br/><span>playable worlds.</span></h2></div>
          <div className="about-copy">
            <p className="lead">I’m a Unity Game Developer focused on building engaging, functional and polished gaming experiences.</p>
            <p>I work with Unity and C# to develop gameplay mechanics, player systems, UI, game scenes, levels, AI behavior, animations and complete game experiences. Whether you need an entire game from scratch or one specific feature inside an existing project, I can build it with a practical, gameplay-first approach.</p>
            <div className="about-points"><span><Check/> Clean implementation</span><span><Check/> Gameplay focused</span><span><Check/> Custom solutions</span></div>
          </div>
        </div>
      </motion.section>

      <section className="pro-section games" id="games">
        <div className="section-top"><div><div className="section-label">02 <span>SELECTED PROJECTS</span></div><h2>My <span>Games</span></h2></div><p>Explore selected Unity projects and game concepts. Open any project to view its details.</p></div>
        <div className="games-grid">
          {projects.map((project, index) => (
            <motion.article className="game-card" key={project.title} initial={{ opacity:0, y:40 }} whileInView={{ opacity:1,y:0 }} viewport={{once:true,amount:.1}} transition={{delay:(index%3)*.08}}>
              <button className="game-image" onClick={(e) => { lastFocus.current=e.currentTarget; setSelectedProject(project); }} aria-label={`View ${project.title} details`}>
                <img src={project.image} alt={project.title} loading="lazy"/>
                <span className="game-index">0{index+1}</span><span className="game-hover">VIEW PROJECT <ArrowUpRight size={16}/></span>
              </button>
              <div className="game-info"><div className="game-meta"><span>{project.genre}</span><span>{project.platform}</span></div><h3>{project.title}</h3><p>{project.description}</p><button onClick={(e)=>{lastFocus.current=e.currentTarget;setSelectedProject(project)}}>Project Details <ChevronRight size={14}/></button></div>
            </motion.article>
          ))}
        </div>
      </section>

      <section className="pro-section services" id="services">
        <div className="section-top"><div><div className="section-label">03 <span>WHAT I CAN BUILD</span></div><h2>Development <span>Services</span></h2></div><p>Need the whole game or one important system? The scope can fit your project.</p></div>
        <div className="services-grid-pro">{services.map(({icon:Icon,title,text},i)=><motion.article key={title} initial={{opacity:0,y:25}} whileInView={{opacity:1,y:0}} viewport={{once:true}} transition={{delay:i*.06}}><span className="service-count">0{i+1}</span><Icon/><h3>{title}</h3><p>{text}</p><span className="service-arrow">↗</span></motion.article>)}</div>
      </section>

      <section className="capability-band">
        <div><span className="section-label">UNITY TOOLKIT</span><h2>Systems, mechanics & <span>experiences.</span></h2></div>
        <div className="skill-cloud">{skills.map(s=><span key={s}>{s}</span>)}</div>
      </section>

      <section className="pro-section process" id="process">
        <div className="section-label">04 <span>HOW I WORK</span></div><h2>From <span>idea</span> to playable.</h2>
        <div className="process-grid">{process.map(([n,t,d])=><article key={n}><b>{n}</b><div><h3>{t}</h3><p>{d}</p></div></article>)}</div>
      </section>

      <section className="pro-section reasons">
        <div className="reasons-head"><div className="section-label">05 <span>WHY WORK TOGETHER</span></div><h2>Built for the<br/><span>game you imagine.</span></h2></div>
        <div className="reason-grid">{reasons.map((r,i)=><div key={r}><span>0{i+1}</span><Check size={15}/><strong>{r}</strong></div>)}</div>
      </section>

      <GameIdeaInquiry />

      <section className="contact-pro" id="contact">
        <div className="contact-glow"/>
        <div className="section-label">07 <span>START A CONVERSATION</span></div>
        <h2>Have a game<br/><span>in mind?</span></h2>
        <p>Tell me what you want to build. I can help turn the idea into a playable Unity experience.</p>
        <div className="contact-buttons"><a className="pro-btn primary" href={`mailto:${portfolio.email}`}>Email Me <Mail size={15}/></a><a className="pro-btn ghost" href={portfolio.whatsapp} target="_blank" rel="noopener noreferrer">WhatsApp <ArrowUpRight size={15}/></a></div>
        <div className="contact-detail"><span>{portfolio.email}</span><span>+92 303 8999792</span></div>
      </section>

      <footer className="pro-footer"><div className="pro-logo"><span className="logo-box">U</span><span><strong>UNITY</strong><small>GAME DEVELOPER</small></span></div><p>Creating games, systems and experiences with Unity & C#.</p><span>© 2026 · All Rights Reserved</span></footer>

      {selectedProject && <div className="project-modal" onMouseDown={e=>{if(e.target===e.currentTarget)setSelectedProject(null)}}><motion.section className="project-modal-inner" initial={{opacity:0,scale:.96,y:20}} animate={{opacity:1,scale:1,y:0}}><button className="dialog-close" onClick={()=>setSelectedProject(null)} aria-label="Close"><X/></button><div className="modal-image"><img src={selectedProject.image} alt={selectedProject.title}/></div><div className="modal-copy"><span>{selectedProject.genre} · {selectedProject.platform}</span><h2>{selectedProject.title}</h2><p>{selectedProject.description}</p>{selectedProject.features?.map(f=><div className="modal-feature" key={f}><Check size={14}/>{f}</div>)}{projectPlayUrl(selectedProject)?<a className="pro-btn primary" href={projectPlayUrl(selectedProject)} target="_blank" rel="noopener noreferrer">Open on Google Play <ArrowUpRight size={15}/></a>:<span className="coming-soon">GOOGLE PLAY LINK — COMING SOON</span>}</div></motion.section></div>}
    </main>
  );
}

function Router() { return <ErrorBoundary><Switch><Route path="/" component={Home}/><Route component={NotFound}/></Switch></ErrorBoundary>; }
function App() { return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/,'')}><Router/></WouterRouter><Toaster/></TooltipProvider></QueryClientProvider>; }
export default App;
